PRAGMA foreign_keys = false;
DROP TABLE IF EXISTS "rules";
CREATE TABLE "rules" (
  "_id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "rule_id" INTEGER,
  "rule_version" INTEGER,
  "rule_module" TEXT,
  "rule_content" TEXT
);
UPDATE "sqlite_sequence" SET seq = 1 WHERE name = 'rules';
PRAGMA foreign_keys = true;
