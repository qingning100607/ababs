PRAGMA foreign_keys = false;
DROP TABLE IF EXISTS "cloud_config";
CREATE TABLE "cloud_config" (
  "_id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "config_name" TEXT,
  "group_name" TEXT,
  "enable" INTEGER,
  "version" INTEGER,
  "with_model" INTEGER,
  "model" TEXT,
  "params" TEXT,
  "anchor" TEXT,
  "anchor_percents" TEXT,
  "anchor_values" TEXT,
  "value_type" TEXT,
  "final_value" TEXT,
  UNIQUE ("config_name" ASC)
);
UPDATE "sqlite_sequence" SET seq = 2 WHERE name = 'cloud_config';
PRAGMA foreign_keys = true;
