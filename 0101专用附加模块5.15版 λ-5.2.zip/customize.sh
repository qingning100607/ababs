set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/bin/sqlite3 0 0 0755
chcon u:object_r:lmkd_exec:s0 "$MODPATH/system/bin/lmkd"
chcon -R "u:object_r:vendor_configs_file:s0" "$MODPATH/system/vendor/etc/"
chown root:shell "$MODPATH/system/bin/lmkd"
chmod 755 "$MODPATH/system/bin/lmkd"

if [ -f /data/adb/ksud ]; then
    /data/adb/ksud sepolicy patch "allow system_server * * *"
elif [ -f /data/adb/apd ]; then
    /data/adb/apd sepolicy patch "allow system_server * * *"
else
    magiskpolicy --live "allow system_server * * *"
    magisk --sqlite "insert or replace into settings values ('mnt_ns', 0)"
fi

BRAND="$(getprop ro.product.brand)"
if [ $BRAND == "Xiaomi" ] || [ $BRAND == "Redmi" ]; then
    ui_print "- Xiaomi 高通 设备"
    cat $MODPATH/miui.prop >>$MODPATH/system.prop    
else     
    abort "- 非小米/红米设备，禁止刷入"
fi
rm -rf $MODPATH/miui.prop

if [ ! -f /system_ext/lib64/libmigui.so ]; then
    rm -rf $MODPATH/modules/perfmgr.ko $MODPATH/config/
fi

device_config put activity_manager max_cached_processes 65535
device_config put activity_manager max_phantom_processes 65535

OVERLAY_IMAGE_EXTRA=0     # number of kb need to be added to overlay.img
OVERLAY_IMAGE_SHRINK=true # shrink overlay.img or not?

if [ -f "/data/adb/modules/magisk_overlayfs/util_functions.sh" ] &&
    /data/adb/modules/magisk_overlayfs/overlayfs_system --test; then
    ui_print "- Add support for overlayfs"
    . /data/adb/modules/magisk_overlayfs/util_functions.sh
    support_overlayfs
    rm -rf "$MODPATH"/system
fi

ui_print "原模块作者nakixii"
ui_print "二改酷安@初春在鹿野"
sleep 5