MODDIR=${0%/*}
MODULE_DIR="/sys/module"
TMPDIR="/dev/mount_lib"

if [ -d /data/adb/modules/FEASHelper ]; then
    touch /data/adb/modules/FEASHelper/disable
    ui_print "已禁用FEASHelp的模块"
fi

if [ -f /system_ext/lib64/libmigui.so ]; then
    if [ "$(getprop ro.hardware)" == "qcom" ]; then
        insmod $MODDIR/modules/perfmgr.ko
        mkdir -p $TMPDIR
        sed 's?ro.product.product.name?ro.product.prodcut.name?' \
            /system_ext/lib64/libmigui.so \
            >$TMPDIR/libmigui.so
        mount --bind "$TMPDIR/libmigui.so" "/system_ext/lib64/libmigui.so"
        restorecon /system_ext/lib64/libmigui.so
        resetprop ro.product.prodcut.name socrates_cn
    else
        abort "非高通芯片禁止刷入"
    fi
fi


[ ! -d "$MODULE_DIR/zram" ] && insmod $MODDIR/modules/zram.ko

chcon "u:object_r:lmkd_exec:s0" "$MODDIR/system/bin/lmkd"
