MODDIR=${0%/*}

# $1:value $2:path
lock_val() {
    if [ -f "$2" ]; then
        umount "$2"
        chown root:root "$2"
        chmod 0666 "$2"
        echo "$1" >"$2"
        chmod 0444 "$2"
        restorecon -R -F "$2"
    fi
}

# $1:value $2:path
mask_val() {
    if [ -f "$2" ]; then
        umount "$2"
        chown root:root "$2"
        chmod 0666 "$2"
        echo "$1" >"$2"
        chmod 0444 "$2"
        restorecon -R -F "$2"

        TIME="$(date "+%s%N")"
        touch "/dev/mount_masks/mount_mask_$TIME"
        echo "$1" >"/dev/mount_masks/mount_mask_$TIME"
        mount --bind "/dev/mount_masks/mount_mask_$TIME" "$2"
        restorecon -R -F "$2"
    fi
}

wait_until_login() {
    # in case of /data encryption is disabled
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done

    # in case of the user unlocked the screen
    until [ -d "/data/data/android" ]; do
        sleep 1
    done
}

init_node_qcom() {
    mask_val "0-3" /dev/cpuset/system-background/cpus

    BUS_DIR="/sys/devices/system/cpu/bus_dcvs"
    for d in $(ls $BUS_DIR); do
        [ ! -f $BUS_DIR/$d/hw_max_freq ] && continue
        MAX_FREQ=$(cat $BUS_DIR/$d/hw_max_freq)
        MIN_FREQ=$(cat $BUS_DIR/$d/hw_min_freq)
        [ "$d" == "DDRQOS" ] && lock_val "$MAX_FREQ" "$BUS_DIR/$d/boost_freq"

        for df in $(ls $BUS_DIR/$d); do
            lock_val "$MAX_FREQ" "$BUS_DIR/$d/$df/max_freq"
        done
    done

    MIN_PWRLVL=$(($(cat /sys/class/kgsl/kgsl-3d0/num_pwrlevels) - 1))
    lock_val "$MIN_PWRLVL" /sys/class/kgsl/kgsl-3d0/default_pwrlevel
    lock_val "$MIN_PWRLVL" /sys/class/kgsl/kgsl-3d0/min_pwrlevel
    lock_val "0" /sys/class/kgsl/kgsl-3d0/max_pwrlevel
    lock_val "0" /sys/class/kgsl/kgsl-3d0/thermal_pwrlevel
    lock_val "0" /sys/class/kgsl/kgsl-3d0/throttling
}

init_platform_config() {
    for i in $(seq 0 7); do
        lock_val "walt" /sys/devices/system/cpu/cpu$i/cpufreq/scaling_governor
        lock_val "0" /sys/devices/system/cpu/cpu$i/core_ctl/enable
        echo 0 > /sys/devices/system/cpu/cpu$i/cpufreq/scaling_min_freq
        echo 2147483647 > /sys/devices/system/cpu/cpu$i/cpufreq/scaling_max_freq
    done

    mask_val "65536 1048576 16777216" /proc/sys/net/ipv4/tcp_rmem
    mask_val "65536 524288 16777216" /proc/sys/net/ipv4/tcp_wmem
    mask_val "1000" /proc/sys/net/ipv4/tcp_max_reordering
    mask_val "1" /proc/sys/net/ipv4/tcp_tw_reuse
    mask_val "0" /proc/sys/net/ipv4/tcp_ecn

    mkdir /dev/cpuset/sf_subsystem
    echo "3-7" > /dev/cpuset/sf_subsystem/cpus
    echo "0" > /dev/cpuset/sf_subsystem/mems
    echo "$(pidof android.hardware.graphics.composer@3.1-service)" > /dev/cpuset/sf_subsystem/cgroup.procs
    echo "$(pidof surfaceflinger)" > /dev/cpuset/sf_subsystem/cgroup.procs

    if [ "$(getprop ro.hardware)" == "qcom" ]; then
        init_node_qcom
    else
        abort "非高通芯片禁止刷入"
    fi
}

# gen_joyose_sql(){
    # {
        # echo "insert or replace into cloud_config "
        # echo -n "(config_name, group_name, enable, version, with_model, params) values "
        # echo -n "('$1', '$1', 1, $2, 0, CAST(readfile('$3') AS TEXT));"
        # echo "select changes();"
    # } >>$MODDIR/config/joyose.sql
# }

gen_teg_config_sql() {
    GEN_JSON="$MODDIR/config/generated/teg_$1.json"
    {
        printf '{"config_name":"%s","group_name":"%s","with_model":false,"enable":true,"version":%s,"params":' "$1" "$1" "$2"
        cat "$3"
        printf '}'
    } >"$GEN_JSON"

    compact_json "$GEN_JSON"

    {
        printf "insert into rules\n"
        printf "(rule_id, rule_version, rule_module, rule_content) values "
        printf "(2147483646, 2147483646, '%s', CAST(readfile('%s') AS TEXT));\n" "$1" "$GEN_JSON"
        printf "select changes();\n"
    } >>"$MODDIR/config/generated/joyose_teg.sql"
}

gen_joyose_sql() {
    GEN_JSON="$MODDIR/config/generated/smartp_$1.json"
    cp -af "$3" "$GEN_JSON"
    compact_json "$GEN_JSON"

    {
        printf "insert into cloud_config(config_name, group_name, enable, version, with_model, params) values ('%s', '%s', 1, '%s', 0, CAST(readfile('%s') AS TEXT));\n" "$1" "$1" "$2" "$GEN_JSON"
        printf "select changes();\n"
    } >>"$MODDIR/config/generated/joyose_cloud.sql"
}

init_joyose_config() {
    JOY_CFG="/data/data/com.xiaomi.joyose/databases/SmartP.db"
    TEG_CFG="/data/data/com.xiaomi.joyose/databases/teg_config.db"
    [ ! -f $JOY_CFG ] && return
    exec_system "am force-stop com.xiaomi.joyose"
    rm -rf "$MODDIR/config/generated"
    mkdir "$MODDIR/config/generated"
    "$MODDIR/bin/sqlite3" $JOY_CFG ".read $MODDIR/config/cloud_config.sql"
    "$MODDIR/bin/sqlite3" $TEG_CFG ".read $MODDIR/config/teg_rules.sql"
    COMMON_VERSION="2029000014"
    BOOSTER_VERSION="2029000014"
    COMMON_JSON="$MODDIR/config/common_config.json"
    DEVICE="$(getprop ro.product.device)"
    if [ "$(getprop ro.hardware)" == "qcom" ]; then
        BOOSTER_JSON="$MODDIR/config/booster_config_qti.json"
    else
        abort "非高通芯片禁止刷入"  
    fi    
    gen_teg_config_sql "common_config" "$COMMON_VERSION" "$COMMON_JSON"
    gen_teg_config_sql "booster_config" "$BOOSTER_VERSION" "$BOOSTER_JSON"
    gen_joyose_sql "common_config" "$COMMON_VERSION" "$COMMON_JSON"
    gen_joyose_sql "booster_config" "$BOOSTER_VERSION" "$BOOSTER_JSON"
    "$MODDIR/bin/sqlite3" $TEG_CFG ".read $MODDIR/config/generated/joyose_teg.sql"
    "$MODDIR/bin/sqlite3" $JOY_CFG ".read $MODDIR/config/generated/joyose_cloud.sql"   
    exec_system "pm disable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver"
    exec_system "am broadcast -a android.intent.action.BOOT_COMPLETED -p com.xiaomi.joyose"
   
    if [ -f /system_ext/lib64/libmigui.so ]; then
        if [ -f /data/adb/ksud ]; then
            /data/adb/ksud sepolicy patch "allow * proc_perfmgr dir { search }"
            /data/adb/ksud sepolicy patch "allow * proc_perfmgr file { ioctl read getattr open }"
            /data/adb/ksud sepolicy patch "allowxperm * proc_perfmgr file ioctl { 0x6701-0x670F }"
        elif [ -f /data/adb/apd ]; then
            /data/adb/apd sepolicy patch "allow * proc_perfmgr dir { search }"
            /data/adb/apd sepolicy patch "allow * proc_perfmgr file { ioctl read getattr open }"
            /data/adb/apd sepolicy patch "allowxperm * proc_perfmgr file ioctl { 0x6701-0x670F }"
        else
            magiskpolicy --live "allow * proc_perfmgr dir { search }"
            magiskpolicy --live "allow * proc_perfmgr file { ioctl read getattr open }"
            magiskpolicy --live "allowxperm * proc_perfmgr file ioctl { 0x6701-0x670F }"
        fi
    fi

    mask_val "0" /sys/kernel/fpsgo/fbt/enable_ceiling
    mask_val "0" /sys/kernel/fpsgo/fbt/limit_cfreq
    mask_val "0" /sys/kernel/fpsgo/fbt/limit_rfreq
    mask_val "0" /sys/kernel/fpsgo/fbt/limit_cfreq_m
    mask_val "0" /sys/kernel/fpsgo/fbt/limit_rfreq_m
    stop power-hal-1-0 && start power-hal-1-0
}

init_xiaomi_config() {
    am force-stop com.xiaomi.trustservice
    pm uninstall --user 0 com.xiaomi.trustservice

    mask_val "1" /proc/package/stat/pause_mode
    lock_val "0" /sys/module/metis/parameters/cluaff_control
    lock_val "0" /sys/module/metis/parameters/mi_fboost_enable
    lock_val "0" /sys/module/metis/parameters/mi_freq_enable
    lock_val "0" /sys/module/metis/parameters/mi_link_enable
    lock_val "0" /sys/module/metis/parameters/mi_switch_enable
    lock_val "0" /sys/module/metis/parameters/mi_viptask
    lock_val "0" /sys/module/metis/parameters/mpc_fboost_enable
    lock_val "0" /sys/module/metis/parameters/vip_link_enable

    for cpu in $(seq 0 7); do
        lock_val "cpu$cpu 2147483647" /sys/class/thermal/thermal_message/cpu_limits
    done
    mask_val "" /sys/class/thermal/thermal_message/cpu_limits
    lock_val "0" /sys/class/thermal/thermal_message/flash_state
    lock_val "0" /sys/class/thermal/thermal_message/market_download_limit
    lock_val "0" /sys/class/thermal/thermal_message/modem_level
    lock_val "0" /sys/class/thermal/thermal_message/modem_limit
    lock_val "0" /sys/class/thermal/thermal_message/modem_rate
    lock_val "0" /sys/class/thermal/thermal_message/poor_modem_limit
    lock_val "0" /sys/class/thermal/thermal_message/temp_state
    lock_val "0" /sys/class/thermal/thermal_message/torch_level
    lock_val "0" /sys/class/thermal/thermal_message/torch_real_level
    lock_val "0" /sys/class/thermal/thermal_message/wifi_limit

    settings put system miui_app_cache_optimization 0
    init_joyose_config
}

init_brand_specific_config() {
    BRAND="$(getprop ro.product.brand)"
    if [ $BRAND == "Xiaomi" ] || [ $BRAND == "Redmi" ]; then
        init_xiaomi_config
    else
        abort  "- 非小米/红米设备，禁止刷入"
    fi
}

init_zram() {
    mask_val "160" /proc/sys/vm/swappiness
    mask_val "32768" /proc/sys/vm/min_free_kbytes
    mask_val "100" /proc/sys/vm/watermark_scale_factor
    mask_val "1" /proc/sys/vm/overcommit_memory
    mask_val "20" /proc/sys/vm/compaction_proactiveness

    if ! grep -q zram /proc/swaps; then
        lock_val "1" /sys/class/block/zram0/reset
        lock_val "0" /sys/class/block/zram0/mem_limit
        lock_val "lz4" /sys/class/block/zram0/comp_algorithm
        lock_val "$(cat /proc/meminfo | awk 'NR==1{print $2*1536}')" /sys/class/block/zram0/disksize
        mkswap /dev/block/zram0
        swapon /dev/block/zram0
        rm /dev/block/zram0
        touch /dev/block/zram0 /dev/block/zram1
    fi

    chcon u:object_r:lmkd_exec:s0 "$MODDIR/system/bin/lmkd"
    stop lmkd && start lmkd
}

init_android_config() {
    device_config set_sync_disabled_for_tests until_reboot
    device_config put activity_manager max_cached_processes 65535
    device_config put activity_manager max_phantom_processes 65535
    device_config put netd_native happy_eyeballs_enable true
    device_config put netd_native parallel_lookup true
    device_config put netd_native sort_nameservers true
    device_config put runtime_native_boot disable_lock_profiling true
    device_config put lmkd_native use_minfree_levels false
    device_config delete lmkd_native thrashing_limit_critical
    device_config put activity_manager use_compaction false

    settings put global settings_enable_monitor_phantom_procs false
}

if [ -f /data/adb/ksud ]; then
    /data/adb/ksud sepolicy patch "allow system_server * * *"
elif [ -f /data/adb/apd ]; then
    /data/adb/apd sepolicy patch "allow system_server * * *"
else
    magisk --sqlite "insert or replace into settings values ('mnt_ns', 0)"
    magiskpolicy --live "allow system_server * * *"
fi
mkdir -p /dev/mount_masks

wait_until_login
init_android_config
init_platform_config
init_brand_specific_config
init_zram
